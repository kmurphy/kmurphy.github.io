from . import app    
from . import views

if __name__ == "__main__":
    app.run()
