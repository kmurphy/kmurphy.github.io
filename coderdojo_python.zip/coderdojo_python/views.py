from datetime import datetime
from flask import Flask, render_template
from flask_analytics import Analytics

import os, yaml


from . import app, menu, sessions

@app.route("/")
def home():
    return render_template("home.html", page="home", menu=menu, sessions=sessions)

@app.route("/todo/")
def todo():
    return render_template("todo.html", page="todo", menu=menu)

# games 

@app.route("/games/")
def games():
    return render_template("games.html", page="games", menu=menu)

@app.route("/fruit_ninja_games/")
def fruit_ninja_games():
    return render_template("games/fruit_ninja_games.html", page="games", menu=menu)
@app.route("/collector_games/")
def collector_games():
    return render_template("games/collector_games.html", page="games", menu=menu)
@app.route("/network_games/")
def network_games():
    return render_template("games/network_games.html", page="games", menu=menu)

# deep dives 

@app.route("/deep_dives/")
def deep_dives():
    return render_template("deep_dives.html", page="deep_dives", menu=menu)

# puzzles

@app.route("/puzzles/")
def puzzles():
    return render_template("puzzles.html", page="puzzles", menu=menu)

def generic_puzzle(name):
  
    source = f"coderdojo_python/templates/puzzles/{name}.yaml"
    puzzle = yaml.unsafe_load(open(source).read())
    if 'number' not in puzzle['hints'][0]:
        for k, hint in enumerate(puzzle['hints']): hint['number'] = k + 1

    hints_state = "show" if app.config['ENV']=="development" else ""
    return render_template("puzzles/puzzle.html", page="puzzles", menu=menu, puzzle=puzzle, hints_state=hints_state)

@app.route("/puzzles/how_many_nines/")
def how_many_nines():
    return generic_puzzle("how_many_nines")

@app.route("/puzzles/multiples_of_3_and_5/")
def multiples_of_3_and_5():
    return generic_puzzle("multiples_of_3_and_5")

