import flask
app = flask.Flask(__name__)

menu = {"games": [
        (" - Games - ", "/games"),
        ("Fruit Ninja Games", "/fruit_ninja_games"),
        ("Collector Games", "/collector_games"),
        ("Network Games", "/network_games"),
    ],
    "deep_dives": [
        (" - Deep Dives - ", "/deep_dives"),
        ("Animating Actors", "/todo")
    ],
    "puzzles": [
        (" - Puzzles - ", "/puzzles"),
        ("How many nines?", "/puzzles/how_many_nines"),
        ("Multiples of 3 and 5", "/puzzles/multiples_of_3_and_5")
    ]
}

sessions = [
    [0, "Week 4 (Saturday 2 May)", """<p>This week we will complete 
    the <a href="network_games#10_words">Network Games (10 words)</a> game. In the last session we 
    <ul>
        <li>Implemented the draw function - still missing the updating of the word on the top left.</li>
        <li>Implement most of the game logic - some issues remain. For example, what happend if we miss?, 
        what happend when we make the word? How do we go up/down a level? </li>
    </ul>
    Today using <a href="network_games#10_words_part_2">Network Games (10 words, part 2)</a> as our starting point we 
    <ul> 
        <li>Will fix the above issues.</li>   
        <li>Our letters are not ... practising social distancing.  Sorry bad joke, but sometimes our letters are too close to eachother. We need to fix this.</li>
    </ul>
    </p>

    """],
    
    [0, "Week 3 (Saturday 25 April)", """<p>This week we will try something different.
        Rather than building on the <a href="network_games">Network Games</a>, 
        that we have been working on for the previous two coder sessions, today we 
        are going to start a new game.  However, this new game has the same structure 
        and similar design as our network game - this is to show you how we can 
        build different games from the same game idea.</p>
		<p>Click on  <a href="network_games#10_words">Network Games (10 words)</a> so start.</p>"""],

    [0, "Week 2 (Saturday 4 April)", """This week we will continue to 
        work on the <a href="network_games">Network Games</a>, starting 
        from <a href="network_games#session_2_start">network_basic.py</a> 
        that we completed last week. From this we will do 
		<ul>
            <li>A small rewrite of the code to fix some issues.</li>
            <li>Add sounds and background music.</li>
            <li>Implement better placement of the dots.</li>
            <li>Extend our game to have levels, better GUI, ...</li>
        </ul>"""],

    [0, "Week 1 (Saturday 28 March)", """Since this will be our first online dojo (vojo?) we will try to simplify 
        things and  all work on the same game. 
        Later, as we get more experience with vojos, 
        we can go off and do our separate things (and you can 
        go back to your current game then, if you wish).</br>
        Today we will work on <a href="network_games">Network Games.</a>"""],
]
for k,s in enumerate(sessions): s[0] = k
