from random import choice

WIDTH, HEIGHT = 800, 600

# TODO create list of tiles

# TODO global variables to store game state

def draw():

    screen.clear()
    screen.fill(color="white")
    screen.draw.text("ShutTheBox", midtop=(WIDTH // 2, 0), color="orange", fontsize=60)

    # TODO display all tiles

    # TODO display cup+dice or dice roll result
    if is_waiting_for_roll:
        # TODO display cup+dice
        pass
    else:
        # TODO display dice roll result
        pass

    # TODO message for player


def roll_one_dice():
    pass


def roll_two_dice():
    pass


def is_game_won():
    pass


def on_mouse_down(pos):
    global is_waiting_for_roll, target, total, message, is_roll_one_allowed

    # TODO - deal with mouse click when is_waiting_for_roll is True
    if is_waiting_for_roll:
        pass

    # TODO - deal with mouse click when is_waiting_for_roll is False (waiting for tiles to be shut)
    pass
