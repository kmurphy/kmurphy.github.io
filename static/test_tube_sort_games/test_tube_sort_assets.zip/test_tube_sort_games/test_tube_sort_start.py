m
# import modules


# global identifiers


def is_empty(tube):
    """Empty tube have no drops."""

    pass


def is_full(tube):
    """Full tube has four drops."""

    pass


def is_complete(tube):
    """Is the current tube complete?
       complete = is full and all drops have the same color."""

    pass


def is_all_complete():
    """Is all tubes complete (or empty)?"""

    pass


def put_drop(drop, tube, ignore_color=False):
    """Put given drop in given tube, optionaly ignoring color constraint."""

    # return early if move is not allowed
    pass

    # move allowed, so drop into given tube
    pass


def get_drop(tube):
    """Get top drop from given tube."""

    pass


def is_valid_move(drop, tube):
    """Return True if given drop can be put in given tube."""

    pass


def start_level():

    # get/set level parameters
    pass

    # create each tube and its drops
    pass

    # Shuffle starting position
    pass

    # reset level counters
    pass


def move_drop(tube):
    """Pick up/drop a drop from/to selected tube."""

    pass


def on_mouse_down(pos):
    """Select tube using mouse click."""

    pass


def on_key_down(key):
    """Select tube using number keys."""

    pass


def update():
    pass


def draw():

    # HUD
    pass

    # each tube (and its drops)
    pass

    # picked drop
    pass

    # end of level/game message
    pass


start_level()
