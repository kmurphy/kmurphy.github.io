WIDTH, HEIGHT = 800, 600
from random import randint

# global game data

ship = Actor("ship", midbottom=(WIDTH // 2, HEIGHT - 10))
ship.time_to_fire = 0

ship_rockets = []

blocks = []

invaders = []
invader_rockets = []


def setup_level():
    """Create level objects - invaders and blocks."""

    global level, rows, cols

    # create invader horde
    pass

    # create blocks
    pass



def update(dt):
    """Update all game objects and respoence to used input."""

    global score, level, speed, invaders, invader_rockets, ship, ship_rockets, blocks, pause


    # STEP 1 - update invader horde

    # determine direction - left to right and down at every turn
    pass

    # move each invader and fire at random
    pass

    # STEP 2 - check for game over due to invaders reaching the ground
    pass

    # STEP 3 - update ship position and fire
    pass

    # STEP 4 - move ship rockets amd invader rockets
    pass

    # STEP 5 - collision detection

    # ship_rockets and blocks - optional
    pass

    # ship_rockets and invaders
    pass

    # invader_rockets and blocks
    pass

    # invader_rockets and ship
    pass

    # STEP 6 - clean up (remove dead objects
    pass


def draw():
    """Draw HUD and game objects."""

    global score, level

    # STEP 1 - HUD
    pass

    # STEP 2 - game objects
    pass


# finally start game
setup_level()
