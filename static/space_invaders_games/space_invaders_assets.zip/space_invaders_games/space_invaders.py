WIDTH, HEIGHT = 800, 600
from random import randint

# global game data

level = 1
score = 0
rows, cols = 3, 7
speed = 2

ship = Actor("ship", midbottom=(WIDTH // 2, HEIGHT - 10))
ship.time_to_fire = 0

ship_rockets = []

blocks = []

invaders = []
invader_rockets = []

ufo = Actor("ufo", pos=(0,60))
ufo.isAlive = False
ufo.speed = 3*speed


def setup_level():
    """Create level objects - invaders and blocks."""

    global level, rows, cols

    # create invader horde
    for row in range(rows):
        for col in range(cols):
            invader = Actor("invader_0_0", pos=(80+90*col,80+60*row))
            invader.isAlive = True
            invaders.append(invader)

    # create blocks
    n = 9
    for k in range(n):
        block = Actor("block_0", pos=( (k+0.5)*WIDTH//n ,HEIGHT-100))
        block.isAlive = True
        block.hits = 0
        blocks.append(block)



def update(dt):
    """Update all game objects and respoence to used input."""

    global score, level, speed, invaders, invader_rockets, ship, ship_rockets, blocks, pause

    # STEP 0
    if not invaders:
        return

    ship.time_to_fire -= dt

    # STEP 1 - update invader horde

    # determine direction - left to right and down at every turn
    xs = [invader.x for invader in invaders]
    if (min(xs)<40 and speed<0) or (max(xs)>WIDTH-50 and speed>0):
        speed = -speed
        dy = 20
        if randint(1,6)==1 and not ufo.isAlive:
            ufo.isAlive = True
            ufo.speed = 3*speed
            ufo.x = 0 if ufo.speed>0 else WIDTH

    else:
        dy = 0

    # move each invader and fire at random
    for invader in invaders:
        invader.x += speed
        invader.y += dy
        if randint(1,100) == 1:
            rocket = Actor("invader_rocket", pos=invader.pos)
            rocket.isAlive = True
            invader_rockets.append(rocket)

    if ufo.isAlive:
        ufo.x += ufo.speed
    if ufo.x<0 or ufo.x>WIDTH:
        ufo.isAlive = False

    # STEP 2 - check for game over due to invaders reaching the ground
    if max([invader.y for invader in invaders]) > HEIGHT - 100:
        quit()


    # STEP 3 - update ship position and fire
    if keyboard.left and ship.midleft[0]>10:
        ship.x -= 10
    if keyboard.right and ship.midright[0]<WIDTH-10:
        ship.x += 10
    if keyboard.space and ship.time_to_fire<=0:
        rocket = Actor("ship_rocket", pos=ship.pos)
        #sounds.ship_fired.play()
        rocket.isAlive = True
        ship_rockets.append(rocket)
        ship.time_to_fire = 0.01

    # STEP 4 - move ship rockets amd invader rockets
    for rocket in ship_rockets:
        rocket.y -= 10
    for rocket in invader_rockets:
        rocket.y += 10

    # STEP 5 - collision detection

    # ship_rockets and blocks - optional
    for rocket in ship_rockets:
        for block in blocks:
            if block.collidepoint(rocket.pos):
                rocket.isAlive = False


    # ship_rockets and invaders
    for rocket in ship_rockets:
        for invader in invaders:
            if invader.collidepoint(rocket.pos):
                rocket.isAlive = False
                invader.isAlive = False
                score = 10
                speed = speed * 1.1

    # ship_rockets and ufo
    if ufo.isAlive:
        for rocket in ship_rockets:
            if ufo.collidepoint(rocket.pos):
                rocket.isAlive = False
                ufo.isAlive = False
                score += 1000
                break

    # invader_rockets and blocks
    for rocket in invader_rockets:
        for block in blocks:
            if block.collidepoint(rocket.pos):
                rocket.isAlive = False
                block.hits += 1
                if block.hits>=3:
                    block.isAlive = False
                else:
                    block.image = "block_%s" % block.hits


    # invader_rockets and ship
    for rocket in invader_rockets:
        if ship.collidepoint(rocket.pos):
            rocket.isAlive = False
            sounds.ship_hit.play()
            #quit()


    # STEP 6 - clean up/remove dead objects
    ship_rockets = [r for r in ship_rockets if r.y>60 and r.isAlive]
    invader_rockets = [r for r in invader_rockets if r.y<HEIGHT-10 and r.isAlive]
    blocks = [b for b in blocks if b.isAlive]
    invaders = [i for i in invaders if i.isAlive]


def draw():
    """Draw HUD and game objects."""

    global score, level

    # STEP 1 - HUD
    screen.clear()
    screen.draw.text("Score %s" % score, topleft=(5,10), fontname="unifont")
    screen.draw.text("Space Invaders", midtop=(WIDTH//2, 0), color="orange", fontsize=40, fontname="unifont")
    screen.draw.text("Level %s" % level, topright=(WIDTH-5,10), fontname="unifont")

    # STEP 2 - game objects
    for rocket in ship_rockets:
        rocket.draw()
    for rocket in invader_rockets:
        rocket.draw()
    for block in blocks:
        block.draw()
    for invader in invaders:
        invader.draw()

    ship.draw()

    if ufo.isAlive:
        ufo.draw()

    if not invaders:
        screen.draw.text("You Win !!", midtop=(WIDTH//2, HEIGHT//2), color="orange", fontsize=80, fontname="unifont")


# finally start game
setup_level()
